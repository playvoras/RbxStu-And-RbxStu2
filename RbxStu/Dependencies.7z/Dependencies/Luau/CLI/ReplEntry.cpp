// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
#include "Repl.h"

int main(int argc, char** argv)
{
    return replMain(argc, argv);
}
